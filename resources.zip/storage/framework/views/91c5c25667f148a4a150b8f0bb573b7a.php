<?php $__env->startSection('title', 'Tambah Course Baru'); ?>

<?php($active = 'Courses'); ?>

<?php $__env->startSection('page'); ?>
    <div class="max-w-xl mx-auto space-y-6">
        <div>
            <a href="<?php echo e(route('courses.index')); ?>" class="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline mb-3">
                <span>&larr; Kembali ke Master Courses</span>
            </a>

            <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-100 dark:border-slate-700/60">
                <div class="flex items-center gap-3 mb-6">
                    <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-lg shrink-0">
                        📚
                    </div>
                    <div>
                        <h1 class="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">Tambah Course Baru</h1>
                        <p class="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Buat kelas / mata pelajaran baru dalam katalog akademik.</p>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                    <div class="mb-5 bg-rose-50 dark:bg-rose-500/10 border border-rose-200/60 dark:border-rose-500/20 text-rose-600 dark:text-rose-400 text-xs p-4 rounded-xl">
                        <ul class="list-disc pl-4 space-y-1">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('courses.store')); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Nama Kelas / Course</label>
                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" required
                            placeholder="Misal: Pemrograman Web Lanjut"
                            class="w-full bg-slate-50 dark:bg-slate-900/60 dark:text-slate-100 border border-slate-200/80 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all">
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Kategori Course</label>
                            <input type="text" name="categories" value="<?php echo e(old('categories')); ?>" required
                                placeholder="Misal: Web, Mobile, Data"
                                class="w-full bg-slate-50 dark:bg-slate-900/60 dark:text-slate-100 border border-slate-200/80 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all">
                        </div>

                        <div>
                            <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Kode Kelas Unik</label>
                            <input type="text" name="code" value="<?php echo e(old('code')); ?>" required
                                placeholder="Misal: WEB-201"
                                class="w-full bg-slate-50 dark:bg-slate-900/60 dark:text-slate-100 border border-slate-200/80 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">Guru Pengampu Kelas (Opsional)</label>
                        <select name="teacher_id" class="w-full bg-slate-50 dark:bg-slate-900/60 dark:text-slate-100 border border-slate-200/80 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all">
                            <option value="">-- Belum ditentukan --</option>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($teacher->id); ?>" <?php echo e(old('teacher_id') == $teacher->id ? 'selected' : ''); ?>>
                                    <?php echo e($teacher->name); ?> (<?php echo e($teacher->specialization ?? 'Guru'); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($teachers->isEmpty()): ?>
                            <p class="text-[11px] text-amber-500 mt-1">
                                Belum ada data guru. <a href="<?php echo e(route('teachers.create')); ?>" class="underline font-bold">Tambah guru</a> dulu jika diperlukan.
                            </p>
                        <?php endif; ?>
                    </div>

                    <div class="p-3 bg-indigo-50/60 dark:bg-indigo-950/30 rounded-xl border border-indigo-100 dark:border-indigo-500/20 text-[11px] text-indigo-700 dark:text-indigo-300 leading-relaxed">
                        ℹ️ <strong>Langkah Selanjutnya:</strong> Setelah course berhasil dibuat, Anda dapat mendaftarkan siswa ke kelas ini dan menambahkan sesi pertemuan untuk presensi.
                    </div>

                    <div class="pt-3 flex items-center justify-end gap-3 border-t border-slate-100 dark:border-slate-700/60">
                        <a href="<?php echo e(route('courses.index')); ?>"
                            class="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition">
                            Batal
                        </a>
                        <button type="submit"
                            class="bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-600 text-white text-xs font-bold rounded-xl px-6 py-2.5 shadow-md hover:shadow-indigo-500/25 transition-all">
                            Simpan Course
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\project-magang-1\resources\views/courses/create.blade.php ENDPATH**/ ?>