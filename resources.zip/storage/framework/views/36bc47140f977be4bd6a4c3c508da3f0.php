<?php $__env->startSection('title', 'Live Class'); ?>

<?php($active = 'Live Class'); ?>

<?php $__env->startSection('page'); ?>
    
    <div class="flex items-center justify-between mb-6">
        <form method="GET" action="<?php echo e(route('live-class.index')); ?>" class="relative w-96">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search.."
                class="w-full bg-white dark:bg-slate-800 dark:text-slate-100 rounded-full pl-10 pr-4 py-2.5 text-sm border border-slate-100 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-200/50 shadow-sm">
            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
        </form>

        <div class="flex items-center gap-3">
            <span class="flex items-center gap-1.5 text-xs font-semibold bg-rose-50 dark:bg-rose-500/10 text-rose-500 px-3 py-1.5 rounded-full border border-rose-100 dark:border-rose-500/20">
                <span class="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span> Live
            </span>
            <button onclick="toggleDarkMode()" title="Ganti mode terang/gelap"
                class="w-9 h-9 rounded-full bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 shadow-sm hover:bg-slate-50">
                <span class="dark:hidden">🌙</span>
                <span class="hidden dark:inline">☀️</span>
            </button>
            <button class="w-9 h-9 rounded-full bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 flex items-center justify-center text-slate-400 shadow-sm hover:bg-slate-50">🔔</button>
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=admin"
                class="w-9 h-9 rounded-full border border-slate-100 dark:border-slate-700 object-cover shadow-sm" alt="avatar">
        </div>
    </div>

    
    <?php if(session('success') || session('status')): ?>
        <div class="mb-6 bg-emerald-50/90 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-sm px-4 py-3 rounded-2xl font-medium border border-emerald-100 dark:border-emerald-500/20">
            <?php echo e(session('success') ?? session('status') ?? 'Live meeting berhasil diproses.'); ?>

        </div>
    <?php endif; ?>

    
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-xl font-bold text-slate-900 dark:text-white">Live Class</h1>
        <a href="<?php echo e(route('live-class.create')); ?>"
           class="bg-indigo-500 hover:bg-indigo-600 text-white text-xs font-bold rounded-xl px-4 py-2.5 shadow-sm transition">
            + Create Meeting
        </a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

        
        <div class="bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-700/60">
            <div class="flex items-center justify-between mb-5">
                <h2 class="font-bold text-base text-slate-900 dark:text-white">Meeting Room</h2>
                <span class="text-slate-300 dark:text-slate-600 text-lg cursor-pointer">⋮</span>
            </div>

            <?php if($liveMeeting): ?>
                <div class="border border-rose-200/80 dark:border-rose-500/30 bg-rose-50/50 dark:bg-rose-500/10 rounded-2xl p-5 shadow-sm">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
                        <span class="text-xs font-extrabold text-rose-500 dark:text-rose-400">LIVE SEKARANG</span>
                    </div>
                    <p class="font-bold text-base text-slate-900 dark:text-white"><?php echo e($liveMeeting->title); ?></p>
                    <p class="text-xs text-slate-400 dark:text-slate-500 mb-5"><?php echo e($liveMeeting->course->name ?? 'Course'); ?></p>
                    <a href="<?php echo e(route('live-class.show', $liveMeeting)); ?>"
                       class="block text-center bg-indigo-500 text-white text-xs font-bold rounded-xl py-3 hover:bg-indigo-600 shadow-sm transition">
                        Gabung Meeting
                    </a>
                </div>
            <?php else: ?>
                <div class="py-10 text-center text-xs text-slate-400 dark:text-slate-500">
                    Tidak ada meeting yang sedang berlangsung.
                </div>
            <?php endif; ?>
        </div>

        
        <div class="bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-700/60">
            <div class="flex items-center justify-between mb-5">
                <h2 class="font-bold text-base text-slate-900 dark:text-white">Weekly Meetings</h2>
                <span class="text-slate-300 dark:text-slate-600 text-lg cursor-pointer">⋮</span>
            </div>

            <div class="space-y-3 max-h-[380px] overflow-y-auto">
                <?php $__empty_1 = true; $__currentLoopData = $upcomingMeetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between border border-slate-100 dark:border-slate-700/60 rounded-2xl px-4 py-3.5 hover:bg-slate-50 dark:hover:bg-slate-700/40 transition">
                        <div>
                            <p class="font-bold text-xs text-slate-800 dark:text-slate-100"><?php echo e($meeting->title); ?></p>
                            <p class="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5"><?php echo e($meeting->scheduled_at->translatedFormat('d M Y, H:i')); ?></p>
                        </div>
                        <form method="POST" action="<?php echo e(route('live-class.start', $meeting)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="text-xs font-bold text-indigo-500 border border-indigo-200 dark:border-indigo-500/30 rounded-xl px-3.5 py-1.5 hover:bg-indigo-50 dark:hover:bg-indigo-500/10 transition">
                                Mulai
                            </button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="py-10 text-center text-xs text-slate-400 dark:text-slate-500">
                        Belum ada jadwal meeting mendatang.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\project-magang-1\resources\views/live-class/index.blade.php ENDPATH**/ ?>