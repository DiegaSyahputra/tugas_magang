    

        

        <?php $__env->startSection('content'); ?>
            <div class="flex min-h-screen">
                <?php echo $__env->make('partials.sidebar', ['active' => $active ?? null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <main class="flex-1 p-6">
                    <?php echo $__env->yieldContent('page'); ?>
                </main>
            </div>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\project-magang-1\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>