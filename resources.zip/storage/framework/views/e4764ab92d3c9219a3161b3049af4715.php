<?php $__env->startSection('title', 'Teachers'); ?>

<?php($active = 'Teachers'); ?>

<?php $__env->startSection('page'); ?>
    
    <div class="flex items-center justify-between mb-6">
        <form method="GET" action="<?php echo e(route('teachers.index')); ?>" class="relative w-96">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Search.."
                class="w-full bg-white dark:bg-slate-800 dark:text-slate-100 rounded-full pl-10 pr-4 py-2.5 text-sm border border-slate-100 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-200/50 shadow-sm">
            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
        </form>

        <div class="flex items-center gap-3">
            <span class="flex items-center gap-1.5 text-xs font-semibold bg-rose-50 dark:bg-rose-500/10 text-rose-500 px-3 py-1.5 rounded-full border border-rose-100 dark:border-rose-500/20">
                <span class="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span> Live
            </span>
            <button onclick="toggleDarkMode()" title="Ganti mode terang/gelap"
                class="w-9 h-9 rounded-full bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 shadow-sm hover:bg-slate-50">
                <span class="dark:hidden">🌙</span>
                <span class="hidden dark:inline">☀️</span>
            </button>
            <button class="w-9 h-9 rounded-full bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 flex items-center justify-center text-slate-400 shadow-sm hover:bg-slate-50">🔔</button>
            <img src="<?php echo e('https://api.dicebear.com/7.x/avataaars/svg?seed=' . urlencode(auth()->user()->name ?? 'User')); ?>"
                class="w-9 h-9 rounded-full border border-slate-100 dark:border-slate-700 object-cover shadow-sm" alt="avatar"
                title="<?php echo e(auth()->user()->name ?? 'User'); ?> (<?php echo e(ucfirst(auth()->user()->role ?? 'guest')); ?>)">
        </div>
    </div>

    
    <?php if(session('status') || session('message') || session('success')): ?>
        <div class="mb-6 bg-emerald-50/90 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-sm px-4 py-3 rounded-2xl font-medium border border-emerald-100 dark:border-emerald-500/20">
            <?php echo e(session('message') ?? session('success') ?? 'Data guru berhasil diproses.'); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        
        <div class="lg:col-span-2 bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-700/60 flex flex-col justify-between min-h-[580px]">
            <div>
                <div class="flex items-center justify-between mb-6">
                    <h2 class="font-bold text-lg text-slate-900 dark:text-white">Teachers</h2>
                    <div class="flex items-center gap-3">
                        <?php if(auth()->user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('teachers.create')); ?>"
                                class="bg-indigo-500 hover:bg-indigo-600 text-white text-xs font-bold rounded-xl px-4 py-2.5 shadow-sm transition">
                                + Create Now
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left">
                        <thead>
                            <tr class="text-slate-400 dark:text-slate-500 border-b border-slate-100 dark:border-slate-700/60 font-semibold">
                                <th class="py-3 px-2 w-8"><input type="checkbox" class="rounded border-slate-300 text-indigo-500 focus:ring-indigo-500"></th>
                                <th class="py-3 px-3">Nama</th>
                                <th class="py-3 px-3">Email</th>
                                <th class="py-3 px-3">Telepon</th>
                                <th class="py-3 px-3">Spesialisasi</th>
                                <th class="py-3 px-2 text-center w-12"></th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50 dark:divide-slate-700/40">
                            <?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-slate-50/60 dark:hover:bg-slate-700/30 transition-colors">
                                    <td class="py-3.5 px-2"><input type="checkbox" class="rounded border-slate-300 text-indigo-500 focus:ring-indigo-500"></td>
                                    <td class="py-3.5 px-3 font-semibold text-slate-800 dark:text-slate-100">
                                        <div class="flex items-center gap-3">
                                            <img src="<?php echo e($t->avatar ?? 'https://api.dicebear.com/7.x/avataaars/svg?seed=' . urlencode($t->name)); ?>" 
                                                 class="w-8 h-8 rounded-full object-cover shrink-0 bg-slate-100 border border-slate-100 dark:border-slate-700" alt="">
                                            <span><?php echo e($t->name); ?></span>
                                        </div>
                                    </td>
                                    <td class="py-3.5 px-3 font-mono text-slate-500 dark:text-slate-400"><?php echo e($t->user?->email ?? '-'); ?></td>
                                    <td class="py-3.5 px-3 text-slate-500 dark:text-slate-400"><?php echo e($t->tel ?? '-'); ?></td>
                                    <td class="py-3.5 px-3">
                                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                                            <?php echo e($t->specialization ?? 'Guru'); ?>

                                        </span>
                                    </td>
                                    <td class="py-3.5 px-2 text-center text-slate-400">
                                        <?php if(auth()->user()->role === 'admin'): ?>
                                            <div class="flex items-center justify-center gap-1.5">
                                                <a href="<?php echo e(route('teachers.edit', $t->id)); ?>" title="Edit Data" class="hover:text-indigo-600 text-slate-400">
                                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                                </a>
                                                <form action="<?php echo e(route('teachers.destroy', $t->id)); ?>" method="POST" onsubmit="return confirm('Hapus guru <?php echo e($t->name); ?>?')">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="hover:text-rose-500 text-slate-400">
                                                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                                    </button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-slate-300">👁️</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="py-8 text-center text-slate-400 dark:text-slate-500">Belum ada data guru.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            
            <div class="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-700/60 mt-4 text-xs text-slate-400">
                <span>Showing 1 to <?php echo e(count($teachers)); ?> of <?php echo e(count($teachers)); ?> results</span>
                
                <div class="flex items-center gap-1">
                    <button class="w-8 h-8 rounded-lg bg-slate-800 dark:bg-slate-700 text-white flex items-center justify-center font-bold text-xs hover:bg-slate-700 transition">&lt;</button>
                    <button class="w-8 h-8 rounded-lg bg-slate-800 dark:bg-slate-700 text-white flex items-center justify-center font-bold text-xs">1</button>
                    <button class="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 flex items-center justify-center font-bold text-xs hover:bg-slate-200 transition">2</button>
                    <button class="w-8 h-8 rounded-lg bg-slate-800 dark:bg-slate-700 text-white flex items-center justify-center font-bold text-xs hover:bg-slate-700 transition">&gt;</button>
                </div>
            </div>
        </div>

        
        <div class="space-y-6">

            
            <div class="bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-700/60">
                <div class="flex items-center justify-between mb-5">
                    <h2 class="font-bold text-base text-slate-900 dark:text-white">Teacher Specialization</h2>
                    <span class="text-slate-300 dark:text-slate-600 text-lg cursor-pointer">⋮</span>
                </div>
                <div class="space-y-3">
                    <?php
                        $specs = $teachers->pluck('specialization')->filter()->unique();
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-700/40 border border-slate-100 dark:border-slate-700">
                            <span class="text-xs font-semibold text-slate-700 dark:text-slate-200">🎯 <?php echo e($spec); ?></span>
                            <span class="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-500/10">
                                <?php echo e($teachers->where('specialization', $spec)->count()); ?> Guru
                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-xs text-slate-400 dark:text-slate-500 py-4 text-center">Belum ada spesialisasi terdaftar.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\project-magang-1\resources\views/teachers/index.blade.php ENDPATH**/ ?>