<?php

namespace Tests\Integration;

use App\Models\AttendanceRecord;
use App\Models\Course;
use App\Models\CourseSession;
use App\Models\Student;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SelfCheckInIntegrationTest extends TestCase
{
    use RefreshDatabase;

    public function test_public_self_checkin_page_can_be_accessed_via_checkin_code(): void
    {
        $session = CourseSession::factory()->create([
            'checkin_code' => 'QRCODE1234',
        ]);

        $response = $this->get(route('checkin.show', 'QRCODE1234'));

        $response->assertOk();
        $response->assertSee($session->title);
    }

    public function test_enrolled_student_can_self_checkin_and_is_marked_present(): void
    {
        $course = Course::factory()->create();
        $student = Student::factory()->create(['name' => 'Siswa Mandiri']);
        $course->students()->attach($student->id, ['enrolled_at' => now()]);

        // Session starting today in the future
        $session = CourseSession::factory()->create([
            'course_id' => $course->id,
            'checkin_code' => 'CHECKINNOW',
            'session_date' => now()->format('Y-m-d'),
            'start_time' => now()->addMinutes(10)->format('H:i'),
            'end_time' => now()->addHours(2)->format('H:i'),
        ]);

        $response = $this->post(route('checkin.store', $session->checkin_code), [
            'student_id' => $student->id,
        ]);

        $response->assertRedirect(route('checkin.show', $session->checkin_code));
        $response->assertSessionHas('checkedIn');

        $this->assertDatabaseHas('attendance_records', [
            'student_id' => $student->id,
            'course_session_id' => $session->id,
            'status' => 'present',
        ]);

        // Verify student attendance rate auto recalculated
        $student->refresh();
        $this->assertEquals(100, $student->attendance_percent);
    }

    public function test_student_checking_in_past_tolerance_is_marked_late(): void
    {
        $course = Course::factory()->create();
        $student = Student::factory()->create();
        $course->students()->attach($student->id, ['enrolled_at' => now()]);

        // Session was scheduled 1 hour ago
        $session = CourseSession::factory()->create([
            'course_id' => $course->id,
            'checkin_code' => 'LATECODE99',
            'session_date' => now()->format('Y-m-d'),
            'start_time' => now()->subHour()->format('H:i'),
            'end_time' => now()->addHour()->format('H:i'),
        ]);

        $response = $this->post(route('checkin.store', $session->checkin_code), [
            'student_id' => $student->id,
        ]);

        $response->assertRedirect(route('checkin.show', $session->checkin_code));

        $this->assertDatabaseHas('attendance_records', [
            'student_id' => $student->id,
            'course_session_id' => $session->id,
            'status' => 'late',
        ]);
    }

    public function test_non_enrolled_student_cannot_self_checkin(): void
    {
        $course = Course::factory()->create();
        $session = CourseSession::factory()->create([
            'course_id' => $course->id,
            'checkin_code' => 'REJECTCODE',
        ]);

        $nonEnrolledStudent = Student::factory()->create();

        $response = $this->post(route('checkin.store', $session->checkin_code), [
            'student_id' => $nonEnrolledStudent->id,
        ]);

        $response->assertSessionHasErrors(['student_id']);
        $this->assertDatabaseMissing('attendance_records', [
            'student_id' => $nonEnrolledStudent->id,
            'course_session_id' => $session->id,
        ]);
    }
}
