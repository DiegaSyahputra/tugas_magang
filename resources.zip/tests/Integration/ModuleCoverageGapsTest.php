<?php

namespace Tests\Integration;

use App\Models\Course;
use App\Models\CourseSession;
use App\Models\Library;
use App\Models\Meeting;
use App\Models\Payment;
use App\Models\Student;
use App\Models\Teacher;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ModuleCoverageGapsTest extends TestCase
{
    use RefreshDatabase;

    protected function tearDown(): void
    {
        Carbon::setTestNow();
        parent::tearDown();
    }

    /*
    |--------------------------------------------------------------------------
    | 1. Attendance Threshold Boundary Tests
    |--------------------------------------------------------------------------
    */

    public function test_attendance_threshold_boundary_69_percent_is_irregular(): void
    {
        // Default threshold is 70%
        // Student in a course with 13 sessions, attending 9 sessions:
        // 9 / 13 = 0.6923... => round(69.23%) = 69%
        $student = Student::factory()->create();
        $course = Course::factory()->create();
        $course->students()->attach($student->id);

        $sessions = CourseSession::factory()->count(13)->create([
            'course_id' => $course->id,
        ]);

        // Attend 9 sessions
        foreach ($sessions->take(9) as $session) {
            $student->attendanceRecords()->create([
                'course_session_id' => $session->id,
                'status' => 'present',
                'method' => 'manual',
            ]);
        }

        $student->refresh();
        $this->assertEquals(69, $student->attendance_percent);
        $this->assertEquals('irregular', $student->status);
    }

    public function test_attendance_threshold_boundary_70_percent_is_regular(): void
    {
        // Exactly 70% attendance gives regular status
        $student = Student::factory()->create();
        $course = Course::factory()->create();
        $course->students()->attach($student->id);

        $sessions = CourseSession::factory()->count(10)->create([
            'course_id' => $course->id,
        ]);

        // Attend 7 of 10 sessions = 70%
        foreach ($sessions->take(7) as $session) {
            $student->attendanceRecords()->create([
                'course_session_id' => $session->id,
                'status' => 'present',
                'method' => 'manual',
            ]);
        }

        $student->refresh();
        $this->assertEquals(70, $student->attendance_percent);
        $this->assertEquals('regular', $student->status);
    }

    public function test_attendance_threshold_respects_custom_config_override(): void
    {
        // Override threshold to 80%
        config(['attendance.regular_threshold' => 80]);

        $student = Student::factory()->create();
        $course = Course::factory()->create();
        $course->students()->attach($student->id);

        $sessions = CourseSession::factory()->count(20)->create([
            'course_id' => $course->id,
        ]);

        // Attend 15 of 20 = 75%
        foreach ($sessions->take(15) as $session) {
            $student->attendanceRecords()->create([
                'course_session_id' => $session->id,
                'status' => 'present',
                'method' => 'manual',
            ]);
        }

        $student->refresh();
        $this->assertEquals(75, $student->attendance_percent);
        // Under 80% threshold, 75% should be irregular
        $this->assertEquals('irregular', $student->status);

        // Add 1 more present record => 16 of 20 = 80%
        $student->attendanceRecords()->create([
            'course_session_id' => $sessions[15]->id,
            'status' => 'present',
            'method' => 'manual',
        ]);

        $student->refresh();
        $this->assertEquals(80, $student->attendance_percent);
        $this->assertEquals('regular', $student->status);
    }

    /*
    |--------------------------------------------------------------------------
    | 2. Dashboard Metrics Verification
    |--------------------------------------------------------------------------
    */

    public function test_dashboard_computes_exact_counts_and_overall_percentage(): void
    {
        $admin = User::factory()->admin()->create();

        // 3 regular students, 1 irregular student (total 4 students)
        Student::factory()->count(3)->create([
            'status' => 'regular',
        ]);
        Student::factory()->create([
            'status' => 'irregular',
        ]);

        $teachers = Teacher::factory()->count(2)->create();
        $course = Course::factory()->create(['teacher_id' => $teachers[0]->id]);
        Course::factory()->count(4)->create(['teacher_id' => $teachers[1]->id]);

        // Active live meeting: started_at set, ended_at null
        $meeting = Meeting::factory()->create([
            'course_id' => $course->id,
            'started_at' => now()->subMinutes(10),
            'ended_at' => null,
        ]);

        $response = $this->actingAs($admin)->get(route('dashboard'));

        $response->assertOk();
        $response->assertViewHas('totalStudents', 4);
        $response->assertViewHas('totalTeachers', 2);
        $response->assertViewHas('totalCourses', 5);
        $response->assertViewHas('regularCount', 3);
        $response->assertViewHas('irregularCount', 1);
        // overallPercent = round((3 / 4) * 100) = 75
        $response->assertViewHas('overallPercent', 75);
        $response->assertViewHas('liveMeeting', function ($viewMeeting) use ($meeting) {
            return $viewMeeting !== null && $viewMeeting->id === $meeting->id;
        });
    }

    /*
    |--------------------------------------------------------------------------
    | 3. Auth Validation Edge Cases
    |--------------------------------------------------------------------------
    */

    public function test_registration_fails_with_duplicate_email(): void
    {
        User::factory()->create(['email' => 'existing@example.com']);

        $response = $this->post(route('register.post'), [
            'name' => 'Duplicate User',
            'email' => 'existing@example.com',
            'password' => 'secret1234',
            'password_confirmation' => 'secret1234',
            'role' => 'student',
        ]);

        $response->assertSessionHasErrors(['email']);
    }

    public function test_registration_fails_with_password_confirmation_mismatch(): void
    {
        $response = $this->post(route('register.post'), [
            'name' => 'Mismatch User',
            'email' => 'mismatch@example.com',
            'password' => 'password123',
            'password_confirmation' => 'different456',
            'role' => 'student',
        ]);

        $response->assertSessionHasErrors(['password']);
    }

    public function test_registration_fails_with_password_under_eight_characters(): void
    {
        $response = $this->post(route('register.post'), [
            'name' => 'Short Pass',
            'email' => 'short@example.com',
            'password' => '1234567',
            'password_confirmation' => '1234567',
            'role' => 'student',
        ]);

        $response->assertSessionHasErrors(['password']);
    }

    public function test_registration_fails_with_invalid_role(): void
    {
        $response = $this->post(route('register.post'), [
            'name' => 'Hacker Role',
            'email' => 'hacker@example.com',
            'password' => 'secret1234',
            'password_confirmation' => 'secret1234',
            'role' => 'superadmin',
        ]);

        $response->assertSessionHasErrors(['role']);
    }

    public function test_login_fails_with_wrong_password_and_flashes_only_email(): void
    {
        $user = User::factory()->create([
            'email' => 'validuser@example.com',
            'password' => bcrypt('correct-password'),
        ]);

        $response = $this->from(route('login'))->post(route('login.post'), [
            'email' => 'validuser@example.com',
            'password' => 'wrong-password',
        ]);

        $response->assertRedirect(route('login'));
        $response->assertSessionHasErrors(['email']);
        $this->assertGuest();
    }

    /*
    |--------------------------------------------------------------------------
    | 4. Payment Edge Cases & Security
    |--------------------------------------------------------------------------
    */

    public function test_payment_creation_fails_with_negative_amount(): void
    {
        $admin = User::factory()->admin()->create();
        $student = Student::factory()->create();

        $response = $this->actingAs($admin)->post(route('payments.store'), [
            'student_id' => $student->id,
            'amount' => -50000,
            'payment_method' => 'Bank Transfer',
        ]);

        $response->assertSessionHasErrors(['amount']);
    }

    public function test_payment_creation_fails_with_non_numeric_amount(): void
    {
        $admin = User::factory()->admin()->create();
        $student = Student::factory()->create();

        $response = $this->actingAs($admin)->post(route('payments.store'), [
            'student_id' => $student->id,
            'amount' => 'seratus-ribu',
            'payment_method' => 'Bank Transfer',
        ]);

        $response->assertSessionHasErrors(['amount']);
    }

    public function test_payment_proof_upload_fails_when_file_exceeds_5mb(): void
    {
        Storage::fake('public');
        $studentUser = User::factory()->student()->create();
        $student = Student::factory()->create(['user_id' => $studentUser->id]);
        $payment = Payment::factory()->create(['student_id' => $student->id]);

        // 6MB file = 6144 KB (max is 5120 KB)
        $largeFile = UploadedFile::fake()->create('proof.pdf', 6144);

        $response = $this->actingAs($studentUser)->post(route('payments.upload-proof', $payment), [
            'proof_file' => $largeFile,
        ]);

        $response->assertSessionHasErrors(['proof_file']);
    }

    public function test_payment_proof_upload_fails_with_unsupported_mime_type(): void
    {
        Storage::fake('public');
        $studentUser = User::factory()->student()->create();
        $student = Student::factory()->create(['user_id' => $studentUser->id]);
        $payment = Payment::factory()->create(['student_id' => $student->id]);

        $invalidFile = UploadedFile::fake()->create('malicious.exe', 100, 'application/x-msdownload');

        $response = $this->actingAs($studentUser)->post(route('payments.upload-proof', $payment), [
            'proof_file' => $invalidFile,
        ]);

        $response->assertSessionHasErrors(['proof_file']);
    }

    public function test_export_invoice_escapes_xss_payload_in_student_name(): void
    {
        Storage::fake('public');
        $admin = User::factory()->admin()->create();
        $student = Student::factory()->create([
            'name' => '<script>alert("XSS")</script>',
        ]);
        $payment = Payment::factory()->create([
            'student_id' => $student->id,
            'amount' => 750000,
        ]);

        $response = $this->actingAs($admin)->get(route('payments.export-invoice', $payment));

        $this->assertEquals(200, $response->getStatusCode());
        $payment->refresh();
        $this->assertNotNull($payment->invoice_path);

        $storedInvoiceContent = Storage::disk('public')->get($payment->invoice_path);
        // Must contain escaped HTML entities, NOT raw unescaped script tag
        $this->assertStringContainsString('&lt;script&gt;alert(&quot;XSS&quot;)&lt;/script&gt;', $storedInvoiceContent);
        $this->assertStringNotContainsString('<script>alert("XSS")</script>', $storedInvoiceContent);
    }

    /*
    |--------------------------------------------------------------------------
    | 5. Library Edge Cases
    |--------------------------------------------------------------------------
    */

    public function test_library_upload_fails_without_file(): void
    {
        $admin = User::factory()->admin()->create();

        $response = $this->actingAs($admin)->post(route('library.store'), [
            'title' => 'Missing File Book',
            'category' => 'Tutorial',
            'file_format' => 'PDF',
        ]);

        $response->assertSessionHasErrors(['file']);
    }

    public function test_library_upload_fails_when_file_exceeds_20mb(): void
    {
        Storage::fake('public');
        $admin = User::factory()->admin()->create();

        // 25MB file = 25600 KB (max is 20480 KB)
        $oversizedFile = UploadedFile::fake()->create('huge-manual.pdf', 25600);

        $response = $this->actingAs($admin)->post(route('library.store'), [
            'title' => 'Too Big Material',
            'category' => 'Documentation',
            'file_format' => 'PDF',
            'file' => $oversizedFile,
        ]);

        $response->assertSessionHasErrors(['file']);
    }

    public function test_library_download_redirects_with_error_when_file_is_missing_from_disk(): void
    {
        Storage::fake('public');
        $student = User::factory()->student()->create();

        $library = Library::factory()->create([
            'file_path' => 'library_files/ghost-file.pdf',
            'downloads' => 0,
        ]);

        $response = $this->actingAs($student)->get(route('library.download', $library));

        $response->assertRedirect();
        $response->assertSessionHas('error');
        $library->refresh();
        $this->assertEquals(0, $library->downloads);
    }

    public function test_library_download_increments_count_and_downloads_file(): void
    {
        Storage::fake('public');
        $student = User::factory()->student()->create();

        Storage::disk('public')->put('library_files/valid-ebook.pdf', 'dummy content');

        $library = Library::factory()->create([
            'title' => 'Mastering Laravel',
            'file_path' => 'library_files/valid-ebook.pdf',
            'downloads' => 5,
        ]);

        $response = $this->actingAs($student)->get(route('library.download', $library));

        $this->assertEquals(200, $response->getStatusCode());
        $library->refresh();
        $this->assertEquals(6, $library->downloads);
    }

    /*
    |--------------------------------------------------------------------------
    | 6. Report Content & Header Assertions
    |--------------------------------------------------------------------------
    */

    public function test_reports_index_calculates_summary_metrics(): void
    {
        $teacher = User::factory()->teacher()->create();

        // 2 regular, 2 irregular
        Student::factory()->count(2)->create(['status' => 'regular']);
        Student::factory()->count(2)->create(['status' => 'irregular']);
        Course::factory()->count(3)->create();

        $response = $this->actingAs($teacher)->get(route('reports.index'));

        $response->assertOk();
        $response->assertViewHas('totalStudents', 4);
        $response->assertViewHas('regularCount', 2);
        $response->assertViewHas('irregularCount', 2);
        $response->assertViewHas('attendanceRate', 50); // 2/4 = 50%
        $response->assertViewHas('coursesSummary');
    }

    public function test_reports_export_pdf_returns_html_report_with_student_records(): void
    {
        Storage::fake('public');
        $admin = User::factory()->admin()->create();

        $student = Student::factory()->create([
            'student_code' => 'STU-9999',
            'name' => 'Report Test Student',
            'status' => 'regular',
            'attendance_percent' => 85,
        ]);

        $course = Course::factory()->create([
            'code' => 'REP-101',
            'name' => 'Report Architecture Class',
        ]);
        $course->students()->attach($student->id);

        $response = $this->actingAs($admin)->get(route('reports.export-pdf'));

        $this->assertEquals(200, $response->getStatusCode());
        $content = $response->streamedContent();

        $this->assertStringContainsString('Laporan Akademik & Performa Platform SkillSet', $content);
        $this->assertStringContainsString('STU-9999', $content);
        $this->assertStringContainsString('Report Test Student', $content);
        $this->assertStringContainsString('REGULAR', $content);
        $this->assertStringContainsString('85%', $content);
        $this->assertStringContainsString('REP-101', $content);
        $this->assertStringContainsString('Report Architecture Class', $content);
    }

    public function test_reports_export_excel_returns_csv_with_proper_headers_and_rows(): void
    {
        Storage::fake('public');
        $admin = User::factory()->admin()->create();

        $student = Student::factory()->create([
            'student_code' => 'STU-CSV-1',
            'name' => 'CSV Student',
            'status' => 'regular',
            'attendance_percent' => 92,
            'tel' => '081299998888',
        ]);

        $response = $this->actingAs($admin)->get(route('reports.export-excel'));

        $this->assertEquals(200, $response->getStatusCode());
        $csvContent = $response->streamedContent();

        // Check CSV header
        $this->assertStringContainsString("ID Siswa,Nama Lengkap,Status Presensi,Persentase Kehadiran,Telepon", $csvContent);
        // Check student row
        $this->assertStringContainsString('"STU-CSV-1","CSV Student","regular","92%","081299998888"', $csvContent);
    }
}
