<?php

namespace Tests\Integration;

use App\Models\AttendanceRecord;
use App\Models\Course;
use App\Models\CourseSession;
use App\Models\Meeting;
use App\Models\Student;
use App\Models\Teacher;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class EndToEndFlowTest extends TestCase
{
    use RefreshDatabase;

    protected function tearDown(): void
    {
        Carbon::setTestNow(); // Reset Carbon mock
        parent::tearDown();
    }

    /**
     * E2E Flow 1: Alur Lengkap Akademik & Presensi:
     * Admin buat Guru -> Guru buat Kursus & Sesi -> Admin buat & daftarkan Siswa ->
     * Siswa Self Check-In -> Statistik berubah di Dashboard, Attendance, dan Isi Dokumen Laporan CSV.
     */
    public function test_complete_academic_and_attendance_lifecycle(): void
    {
        Storage::fake('public');
        Carbon::setTestNow('2026-10-22 09:05:00'); // Sesi hari ini jam 09:00, check-in jam 09:05 (toleransi 15 mnt => present)

        $admin = User::factory()->admin()->create();

        // 1. Admin membuat Guru baru
        $teacherPayload = [
            'name' => 'Dr. Bambang Setiawan',
            'email' => 'bambang.setiawan@skillset.com',
            'tel' => '081299887766',
            'specialization' => 'Web Architecture & Cloud',
        ];
        $this->actingAs($admin)->post(route('teachers.store'), $teacherPayload)
            ->assertRedirect(route('teachers.index'));

        $teacherUser = User::where('email', 'bambang.setiawan@skillset.com')->first();
        $this->assertNotNull($teacherUser);
        $teacher = Teacher::where('user_id', $teacherUser->id)->first();
        $this->assertNotNull($teacher);

        // 2. Guru membuat Course baru
        $coursePayload = [
            'name' => 'Fullstack Laravel 12 Masterclass',
            'categories' => 'Web Development',
            'code' => 'FS-LARA-12',
            'teacher_id' => $teacher->id,
        ];
        $this->actingAs($teacherUser)->post(route('courses.store'), $coursePayload);
        $course = Course::where('code', 'FS-LARA-12')->first();
        $this->assertNotNull($course);

        // 3. Guru membuat Sesi Pertemuan pertama (hari ini 09:00 - 11:00)
        $sessionPayload = [
            'title' => 'Pertemuan 1: Instalasi & Arsitektur MVC',
            'session_date' => '2026-10-22',
            'start_time' => '09:00',
            'end_time' => '11:00',
        ];
        $this->actingAs($teacherUser)->post(route('courses.sessions.store', $course), $sessionPayload);
        $session = CourseSession::where('course_id', $course->id)->first();
        $this->assertNotNull($session);
        $this->assertNotEmpty($session->checkin_code);

        // 4. Admin membuat Siswa baru
        $studentPayload = [
            'name' => 'Rian Pratama',
            'email' => 'rian.pratama@skillset.com',
            'tel' => '081344556677',
            'date_birth' => '2004-03-20',
            'status' => 'irregular',
        ];
        $this->actingAs($admin)->post(route('students.store'), $studentPayload)
            ->assertRedirect(route('students.index'));

        $student = Student::where('name', 'Rian Pratama')->first();
        $this->assertNotNull($student);
        $studentUser = $student->user;
        $this->assertNotNull($studentUser);

        // 5. Admin mendaftarkan Siswa ke Course
        $this->actingAs($admin)->post(route('courses.enroll', $course), [
            'student_id' => [$student->id],
        ]);
        $this->assertDatabaseHas('course_student', [
            'course_id' => $course->id,
            'student_id' => $student->id,
        ]);

        // Karena sudah terdaftar di 1 sesi tapi belum diabsen, kehadiran siswa harus 0%
        $student->refresh();
        $this->assertEquals(0, $student->attendance_percent);
        $this->assertEquals('irregular', $student->status);

        // 6. Siswa melakukan Self Check-In via kode sesi publik
        $this->post(route('checkin.store', $session->checkin_code), [
            'student_id' => $student->id,
        ])->assertRedirect(route('checkin.show', $session->checkin_code));

        // 7. Verifikasi Perubahan Menyeluruh (Ripple Effect)
        // a. Catatan absensi tersimpan dengan status 'present'
        $this->assertDatabaseHas('attendance_records', [
            'student_id' => $student->id,
            'course_session_id' => $session->id,
            'status' => 'present',
        ]);

        // b. Siswa otomatis berubah menjadi 100% dan status 'regular'
        $student->refresh();
        $this->assertEquals(100, $student->attendance_percent);
        $this->assertEquals('regular', $student->status);

        // c. Dashboard mencerminkan statistik siswa regular
        $dashResponse = $this->actingAs($admin)->get(route('dashboard'));
        $dashResponse->assertOk();
        $dashResponse->assertViewHas('regularCount', 1);
        $dashResponse->assertViewHas('irregularCount', 0);
        $dashResponse->assertViewHas('overallPercent', 100.0);

        // d. Laporan Kehadiran CSV memuat nama siswa, NIM, 100%, dan status REGULAR
        $csvResponse = $this->actingAs($admin)->get(route('reports.export-excel'));
        $csvResponse->assertOk();

        // Baca file CSV yang disimpan di storage
        $files = Storage::disk('public')->files('reports');
        $csvFile = collect($files)->first(fn ($f) => str_ends_with($f, '.csv'));
        $this->assertNotNull($csvFile);
        $csvContent = Storage::disk('public')->get($csvFile);

        $this->assertStringContainsString($student->student_code, $csvContent);
        $this->assertStringContainsString('Rian Pratama', $csvContent);
        $this->assertStringContainsString('regular', $csvContent);
        $this->assertStringContainsString('100%', $csvContent);
    }

    /**
     * E2E Flow 2: Live Class Meeting dengan Sesi Terhubung:
     * Jadwalkan Meeting -> Mulai Meeting -> Siswa Join & Check-In -> Chatting -> Siswa Check-Out -> Durasi Tercatat -> Selesai.
     */
    public function test_live_class_meeting_connected_to_session_lifecycle(): void
    {
        Carbon::setTestNow('2026-10-22 14:00:00');

        $teacherUser = User::factory()->teacher()->create();
        $studentUser = User::factory()->student()->create();
        $student = Student::factory()->create(['user_id' => $studentUser->id]);

        $course = Course::factory()->create();
        $session = CourseSession::factory()->create(['course_id' => $course->id]);
        $course->students()->attach($student->id);

        // 1. Guru menjadwalkan Live Class
        $meetingPayload = [
            'course_id' => $course->id,
            'course_session_id' => $session->id,
            'title' => 'Live Coding: RESTful API di Laravel 12',
            'scheduled_at' => '2026-10-22 14:00:00',
            'duration_minutes' => 60,
        ];
        $this->actingAs($teacherUser)->post(route('live-class.store'), $meetingPayload);
        $meeting = Meeting::where('title', 'Live Coding: RESTful API di Laravel 12')->first();
        $this->assertNotNull($meeting);

        // 2. Guru memulai meeting (jam 14:00)
        $this->actingAs($teacherUser)->post(route('live-class.start', $meeting));
        $meeting->refresh();
        $this->assertEquals('live', $meeting->status);

        // 3. Siswa bergabung ke video call (trigger check-in)
        $this->actingAs($studentUser)->postJson(route('live-class.check-in', $meeting), [
            'student_id' => $student->id,
        ])->assertJson(['recorded' => true]);

        $record = AttendanceRecord::where('student_id', $student->id)
            ->where('course_session_id', $session->id)
            ->first();
        $this->assertNotNull($record);
        $this->assertEquals('present', $record->status);

        // 4. Guru & Siswa mengirim pesan chat
        $this->actingAs($teacherUser)->postJson(route('live-class.messages.store', $meeting), [
            'sender_name' => $teacherUser->name,
            'message' => 'Selamat datang di live coding sesi ini!',
        ])->assertJson(['success' => true]);

        Carbon::setTestNow('2026-10-22 14:10:00');
        $this->actingAs($studentUser)->postJson(route('live-class.messages.store', $meeting), [
            'sender_name' => $student->name,
            'message' => 'Siap pak, suara dan layar terlihat jelas.',
        ])->assertJson(['success' => true]);

        $chatResponse = $this->actingAs($studentUser)->getJson(route('live-class.messages.index', $meeting));
        $chatData = $chatResponse->json();
        $this->assertEquals('Selamat datang di live coding sesi ini!', $chatData[0]['message']);
        $this->assertEquals('Siap pak, suara dan layar terlihat jelas.', $chatData[1]['message']);

        // 5. Siswa keluar video call setelah 50 menit (14:50) -> trigger check-out
        Carbon::setTestNow('2026-10-22 14:50:00');
        $this->actingAs($studentUser)->postJson(route('live-class.check-out', $meeting), [
            'student_id' => $student->id,
        ])->assertJson(['recorded' => true]);

        $record->refresh();
        $this->assertEquals(50, $record->duration_minutes);
        $this->assertEquals('0 hr 50 min', $record->duration_label);

        // 6. Guru mengakhiri meeting
        $this->actingAs($teacherUser)->post(route('live-class.end', $meeting));
        $meeting->refresh();
        $this->assertEquals('ended', $meeting->status);
    }
}
