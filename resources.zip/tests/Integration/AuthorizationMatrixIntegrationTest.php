<?php

namespace Tests\Integration;

use App\Models\Course;
use App\Models\CourseSession;
use App\Models\Meeting;
use App\Models\Student;
use App\Models\Teacher;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

class AuthorizationMatrixIntegrationTest extends TestCase
{
    use RefreshDatabase;

    protected User $admin;
    protected User $teacherUser;
    protected User $studentUser;

    protected Student $student;
    protected Teacher $teacher;
    protected Course $course;
    protected CourseSession $session;
    protected Meeting $meeting;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->admin()->create();
        $this->teacherUser = User::factory()->teacher()->create();
        $this->studentUser = User::factory()->student()->create();

        $this->student = Student::factory()->create();
        $this->teacher = Teacher::factory()->create();
        $this->course = Course::factory()->create(['teacher_id' => $this->teacher->id]);
        $this->course->students()->attach($this->student->id);
        $this->session = CourseSession::factory()->create(['course_id' => $this->course->id]);
        $this->meeting = Meeting::factory()->create([
            'course_id' => $this->course->id,
            'course_session_id' => $this->session->id,
        ]);
    }

    /**
     * Matriks Otorisasi untuk Operasi Penulisan/Mutasi Data (POST, PUT, DELETE).
     */
    #[DataProvider('writeActionMatrix')]
    public function test_write_action_authorization_matrix(
        string $method,
        string $routeKey,
        string $role,
        int $expectedStatus
    ): void {
        $uri = $this->resolveRouteUri($routeKey);

        $request = match ($role) {
            'guest' => $this,
            'student' => $this->actingAs($this->studentUser),
            'teacher' => $this->actingAs($this->teacherUser),
            'admin' => $this->actingAs($this->admin),
        };

        $response = match ($method) {
            'GET' => $request->get($uri),
            'POST' => $request->post($uri, $this->samplePayload($routeKey)),
            'PUT' => $request->put($uri, $this->samplePayload($routeKey)),
            'DELETE' => $request->delete($uri),
        };

        if ($expectedStatus === 302 && $role === 'guest') {
            $response->assertRedirect('/login');
        } elseif ($expectedStatus === 403) {
            $response->assertForbidden();
        } else {
            // Sukses (bisa 200 OK untuk export, atau 302 redirect dengan status sukses untuk submit form)
            $statusCode = $response->baseResponse->getStatusCode();
            $this->assertTrue(
                in_array($statusCode, [200, 302]),
                "Aksi {$method} {$uri} oleh role {$role} gagal dengan status {$statusCode}."
            );
        }
    }

    public static function writeActionMatrix(): array
    {
        return [
            // Master Siswa: Hanya Admin (Student & Teacher -> 403)
            ['POST', 'students.store', 'guest', 302],
            ['POST', 'students.store', 'student', 403],
            ['POST', 'students.store', 'teacher', 403],
            ['POST', 'students.store', 'admin', 302],

            ['PUT', 'students.update', 'student', 403],
            ['PUT', 'students.update', 'teacher', 403],
            ['PUT', 'students.update', 'admin', 302],

            ['DELETE', 'students.destroy', 'student', 403],
            ['DELETE', 'students.destroy', 'teacher', 403],
            ['DELETE', 'students.destroy', 'admin', 302],

            // Master Guru: Hanya Admin
            ['POST', 'teachers.store', 'student', 403],
            ['POST', 'teachers.store', 'teacher', 403],
            ['POST', 'teachers.store', 'admin', 302],

            ['PUT', 'teachers.update', 'student', 403],
            ['PUT', 'teachers.update', 'teacher', 403],
            ['PUT', 'teachers.update', 'admin', 302],

            ['DELETE', 'teachers.destroy', 'student', 403],
            ['DELETE', 'teachers.destroy', 'teacher', 403],
            ['DELETE', 'teachers.destroy', 'admin', 302],

            // Course: Admin & Teacher boleh membuat
            ['POST', 'courses.store', 'student', 403],
            ['POST', 'courses.store', 'teacher', 302],
            ['POST', 'courses.store', 'admin', 302],

            // Course Enroll: Admin & Teacher boleh
            ['POST', 'courses.enroll', 'student', 403],
            ['POST', 'courses.enroll', 'teacher', 302],
            ['POST', 'courses.enroll', 'admin', 302],

            // Course Un-enroll: Hanya Admin
            ['DELETE', 'courses.students.destroy', 'student', 403],
            ['DELETE', 'courses.students.destroy', 'teacher', 403],
            ['DELETE', 'courses.students.destroy', 'admin', 302],

            // Sesi Pertemuan: Buat & Update (Admin & Teacher), Hapus (Hanya Admin)
            ['POST', 'courses.sessions.store', 'student', 403],
            ['POST', 'courses.sessions.store', 'teacher', 302],
            ['POST', 'courses.sessions.store', 'admin', 302],

            ['PUT', 'courses.sessions.update', 'student', 403],
            ['PUT', 'courses.sessions.update', 'teacher', 302],
            ['PUT', 'courses.sessions.update', 'admin', 302],

            ['DELETE', 'courses.sessions.destroy', 'student', 403],
            ['DELETE', 'courses.sessions.destroy', 'teacher', 403],
            ['DELETE', 'courses.sessions.destroy', 'admin', 302],

            // Absensi Manual: Admin & Teacher
            ['POST', 'attendance.take.store', 'student', 403],
            ['POST', 'attendance.take.store', 'teacher', 302],
            ['POST', 'attendance.take.store', 'admin', 302],

            // Live Class: Admin & Teacher
            ['POST', 'live-class.store', 'student', 403],
            ['POST', 'live-class.store', 'teacher', 302],
            ['POST', 'live-class.store', 'admin', 302],

            ['POST', 'live-class.start', 'student', 403],
            ['POST', 'live-class.start', 'teacher', 302],
            ['POST', 'live-class.start', 'admin', 302],

            ['POST', 'live-class.end', 'student', 403],
            ['POST', 'live-class.end', 'teacher', 302],
            ['POST', 'live-class.end', 'admin', 302],

            // Reports Export: Admin & Teacher
            ['GET', 'reports.export-pdf', 'student', 403],
            ['GET', 'reports.export-pdf', 'teacher', 200],
            ['GET', 'reports.export-pdf', 'admin', 200],

            ['GET', 'reports.export-excel', 'student', 403],
            ['GET', 'reports.export-excel', 'teacher', 200],
            ['GET', 'reports.export-excel', 'admin', 200],
        ];
    }

    private function resolveRouteUri(string $routeKey): string
    {
        return match ($routeKey) {
            'students.store' => route('students.store'),
            'students.update' => route('students.update', $this->student->id),
            'students.destroy' => route('students.destroy', $this->student->id),

            'teachers.store' => route('teachers.store'),
            'teachers.update' => route('teachers.update', $this->teacher->id),
            'teachers.destroy' => route('teachers.destroy', $this->teacher->id),

            'courses.store' => route('courses.store'),
            'courses.enroll' => route('courses.enroll', $this->course),
            'courses.students.destroy' => route('courses.students.destroy', ['course' => $this->course, 'student' => $this->student]),

            'courses.sessions.store' => route('courses.sessions.store', $this->course),
            'courses.sessions.update' => route('courses.sessions.update', ['course' => $this->course, 'session' => $this->session]),
            'courses.sessions.destroy' => route('courses.sessions.destroy', ['course' => $this->course, 'session' => $this->session]),

            'attendance.take.store' => route('attendance.take.store', $this->session),

            'live-class.store' => route('live-class.store'),
            'live-class.start' => route('live-class.start', $this->meeting),
            'live-class.end' => route('live-class.end', $this->meeting),

            'reports.export-pdf' => route('reports.export-pdf'),
            'reports.export-excel' => route('reports.export-excel'),
        };
    }

    private function samplePayload(string $routeKey): array
    {
        return match ($routeKey) {
            'students.store' => [
                'name' => 'Sample Student',
                'email' => 'sample' . uniqid() . '@skillset.com',
                'tel' => '081234567890',
                'date_birth' => '2004-01-01',
                'status' => 'regular',
            ],
            'students.update' => [
                'name' => 'Updated Name',
                'tel' => '081234567890',
                'date_birth' => '2004-01-01',
                'status' => 'regular',
            ],
            'teachers.store' => [
                'name' => 'Sample Teacher',
                'email' => 'teacher' . uniqid() . '@skillset.com',
                'tel' => '081298765432',
                'specialization' => 'Computer Science',
            ],
            'teachers.update' => [
                'name' => 'Updated Teacher',
                'tel' => '081298765432',
                'specialization' => 'Computer Science',
            ],
            'courses.store' => [
                'name' => 'Sample Course',
                'code' => 'SMP-' . uniqid(),
            ],
            'courses.enroll' => [
                'student_id' => [$this->student->id],
            ],
            'courses.sessions.store', 'courses.sessions.update' => [
                'title' => 'Pertemuan Sample',
                'session_date' => now()->format('Y-m-d'),
                'start_time' => '08:00',
                'end_time' => '10:00',
            ],
            'attendance.take.store' => [
                'attendance' => [$this->student->id => 'present'],
            ],
            'live-class.store' => [
                'course_id' => $this->course->id,
                'title' => 'Sample Live Class',
                'scheduled_at' => now()->addDay()->format('Y-m-d H:i:s'),
                'duration_minutes' => 60,
            ],
            default => [],
        };
    }
}
